package com.sujata.demo;

public class MainHeight {

	public static void main(String[] args) {
		Height height = new Height(5,18);
		height.displayHeight();

	}

}
