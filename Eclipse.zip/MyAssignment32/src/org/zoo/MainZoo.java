package org.zoo;

public class MainZoo {

	public static void main(String[] args) {
		DelhiZoo dzOb = new DelhiZoo();
		dzOb.display();
	}

}
