package com.sujata.demo;

public class CalculateEgg {
	private int totalEggs;
	
	Eggs egg = new Eggs();

	public void setTotalEggs(int totalEggs) {
		this.totalEggs = totalEggs;
	}
	
	public void calculateEgg() {
		egg.setGross(totalEggs/144);
		totalEggs %= 144;
		egg.setDozen(totalEggs/12);
		totalEggs %= 12;
		egg.setRemaining(totalEggs);
	}	
	
	public void display() {
		System.out.println("Nos of Gross Eggs: "+ egg.getGross() + "\nNos of Dozen Eggs: "+ egg.getDozen() + "\nand Remaining Eggs: "+egg.getRemaining());
	}
}
