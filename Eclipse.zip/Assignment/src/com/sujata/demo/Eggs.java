package com.sujata.demo;

public class Eggs {
	
	private int gross;
	private int dozen;
	private int remaining;
	
	public void setGross(int gross) {
		this.gross = gross;
	}
	public void setDozen(int dozen) {
		this.dozen = dozen;
	}
	public void setRemaining(int remaining) {
		this.remaining = remaining;
	}
	
	
	public int getGross() {
		return gross;
	}
	public int getDozen() {
		return dozen;
	}
	public int getRemaining() {
		return remaining;
	}
		
}
