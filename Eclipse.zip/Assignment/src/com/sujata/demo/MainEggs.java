package com.sujata.demo;

public class MainEggs {

	public static void main(String[] args) {
		CalculateEgg eOb = new CalculateEgg();
		
		eOb.setTotalEggs(400);
		eOb.calculateEgg();
		eOb.display();
	}

}