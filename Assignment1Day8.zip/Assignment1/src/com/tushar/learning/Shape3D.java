package com.tushar.learning;

abstract public class Shape3D {
	final double PI = 3.14;

	abstract public void volume();
	abstract public void surfaceArea();
	
}
